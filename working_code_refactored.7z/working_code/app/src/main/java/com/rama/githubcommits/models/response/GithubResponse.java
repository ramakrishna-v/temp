package com.rama.githubcommits.models.response;

import com.rama.githubcommits.models.RepoInfo;

import java.util.ArrayList;

public class GithubResponse{

    public ArrayList<RepoInfo> results;

//  public GithubResponse(String result, String message) {
//        super(result, message);
//    }
}
