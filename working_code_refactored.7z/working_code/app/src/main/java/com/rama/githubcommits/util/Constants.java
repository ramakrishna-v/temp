package com.rama.githubcommits.util;

public class Constants {
    public static final String BASE_URL                 = "https://api.github.com/repos/";
}
