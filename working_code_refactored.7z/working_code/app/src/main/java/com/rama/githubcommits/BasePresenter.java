package com.rama.githubcommits;

public interface BasePresenter<T> {
    void takeView(T view);
    void dropView();
}
