package com.rama.githubcommits.datalayer;

import android.support.annotation.NonNull;
import com.rama.githubcommits.datalayer.source.remote.listeners.NetworkListener;
import com.rama.githubcommits.models.RepoInfo;

import java.util.ArrayList;

public interface CommitsDataSource {

    interface LoadsCommitsCallback extends NetworkListener {
        void onCommitsLoaded(ArrayList<RepoInfo> commits);
    }
    void getCommitsList(@NonNull LoadsCommitsCallback callback);
}
