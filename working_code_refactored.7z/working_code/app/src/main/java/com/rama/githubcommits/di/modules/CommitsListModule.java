package com.rama.githubcommits.di.modules;

import com.rama.githubcommits.di.scopes.ActivityScope;
import com.rama.githubcommits.di.scopes.FragmentScope;
import com.rama.githubcommits.presenter.CommitsPresenter;
import com.rama.githubcommits.CommitsContract;
import com.rama.githubcommits.view.CommitsView;

import dagger.Binds;
import dagger.Module;
import dagger.android.ContributesAndroidInjector;

@Module
public abstract class CommitsListModule {
    @FragmentScope
    @ContributesAndroidInjector
    abstract CommitsView commitsListFragment();

    @ActivityScope
    @Binds
    abstract CommitsContract.Presenter moviePresenter(CommitsPresenter presenter);
}
