package com.rama.githubcommits.datalayer.source.remote.apis;

import com.rama.githubcommits.models.RepoInfo;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.GET;

public interface GitHubApiConfig {
    @GET("WordPress/WordPress/commits")
    Call<ArrayList<RepoInfo>>executeGitHubInfo();
}