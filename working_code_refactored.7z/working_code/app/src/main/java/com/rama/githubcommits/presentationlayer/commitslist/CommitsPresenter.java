
package com.rama.githubcommits.presentationlayer.commitslist;

import android.app.Activity;
import android.support.annotation.Nullable;

import com.rama.githubcommits.datalayer.CommitsDataSource;
import com.rama.githubcommits.datalayer.CommitsRepository;
import com.rama.githubcommits.di.scopes.ActivityScope;
import com.rama.githubcommits.models.RepoInfo;
import com.rama.githubcommits.models.response.GeneralResponse;

import java.util.ArrayList;

import javax.inject.Inject;

@ActivityScope
public class CommitsPresenter implements CommitsContract.Presenter {
    @Nullable
    private CommitsContract.View views;
    private CommitsRepository commitsRepository;
    private boolean setAdapter = true;
    private boolean forceUpdate;
    @Nullable
    private Activity activity;

    @Inject
    CommitsPresenter(CommitsRepository commitsRepository) {
        this.commitsRepository = commitsRepository;
    }

    @Override
    public void loadCommits() {
        startLoading();
    }

    private void startLoading(){

        commitsRepository.getCommitsList(new CommitsDataSource.LoadsCommitsCallback() {
            @Override
            public void noInternetConnection() {
                views.showNoInternetConnection();
            }

            @Override
            public void onErrorResponse(String TAG, GeneralResponse response) {
                views.showServerError(response.getMessage());
            }

            @Override
            public void onCommitsLoaded(ArrayList<RepoInfo> commits) {
                if (commits.size() > 0) {
                    //views.showCommits(commits, setAdapter);
                } else {
                    views.showNoCommits();
                }
            }
        });

    }

    @Override
    public void setActivity(Activity activity) {
        this.activity = activity;
    }


    @Override
    public void takeView(CommitsContract.View view) {
        this.views = view;
    }

    @Override
    public void dropView() {
        this.views = null;
    }
}