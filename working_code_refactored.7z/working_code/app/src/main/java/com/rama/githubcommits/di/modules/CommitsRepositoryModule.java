
package com.rama.githubcommits.di.modules;

import com.rama.githubcommits.datalayer.CommitsDataSource;
import com.rama.githubcommits.datalayer.source.remote.CommitsRemoteDataSource;
import com.rama.githubcommits.di.scopes.Remote;

import javax.inject.Singleton;

import dagger.Binds;
import dagger.Module;

@Module
public abstract class CommitsRepositoryModule {

    @Singleton
    @Binds
    @Remote
    abstract CommitsDataSource provideRemoteDataSource(CommitsRemoteDataSource dataSource);
}
