/*
 * Copyright (C) 2018 Shehab Salah Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.rama.githubcommits.presentationlayer.commitslist;

import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.rama.githubcommits.R;
import com.rama.githubcommits.models.RepoInfo;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CommitsAdapter extends RecyclerView.Adapter<CommitsAdapter.MyViewHolder>{
    private ArrayList<RepoInfo> commits;
    private CommitsContract.Presenter presenter;

    CommitsAdapter(ArrayList<RepoInfo> commits, CommitsContract.Presenter presenter) {
        this.commits = commits;
        this.presenter = presenter;
    }

    void replaceData(ArrayList<RepoInfo> commits) {
        setList(commits);
        notifyDataSetChanged();
    }

    private void setList(ArrayList<RepoInfo> commits) {
        if (commits!=null)
            this.commits = commits;
    }

    static class MyViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.movie_poster)
        ImageView moviePoster;
        @BindView(R.id.movie_title)
        TextView movieTitle;
        @BindView(R.id.item_container)
        CardView cardView;

        MyViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_list_movie, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        RepoInfo movie = commits.get(position);
        //holder.movieTitle.setText(movie.getTitle());
    }

    @Override
    public int getItemCount() {
        return commits!=null?commits.size():0;
    }
}
