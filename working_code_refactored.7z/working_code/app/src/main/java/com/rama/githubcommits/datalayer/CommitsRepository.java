package com.rama.githubcommits.datalayer;

import android.support.annotation.NonNull;

import com.rama.githubcommits.di.scopes.Remote;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class CommitsRepository implements CommitsDataSource {

    private final CommitsDataSource mCommitsRemoteDataSource;

    @Inject
    CommitsRepository(@Remote CommitsDataSource commitsRemoteDataSource) {
        mCommitsRemoteDataSource = commitsRemoteDataSource;
    }

    private void getCommitsFromServer(@NonNull LoadsCommitsCallback callback) {
        mCommitsRemoteDataSource.getCommitsList(callback);
    }

    @Override
    public void getCommitsList(@NonNull final LoadsCommitsCallback callback) {
        getCommitsFromServer(callback);
    }
}
