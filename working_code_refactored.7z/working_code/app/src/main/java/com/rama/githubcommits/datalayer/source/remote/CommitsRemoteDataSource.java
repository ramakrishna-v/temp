
package com.rama.githubcommits.datalayer.source.remote;

import android.app.Application;
import android.support.annotation.NonNull;

import com.rama.githubcommits.datalayer.CommitsDataSource;
import com.rama.githubcommits.datalayer.source.remote.apis.GitHubApiConfig;
import com.rama.githubcommits.datalayer.source.remote.request.RequestHandler;
import com.rama.githubcommits.util.Constants;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class CommitsRemoteDataSource implements CommitsDataSource {
    private Application application;

    @Inject
    CommitsRemoteDataSource(Application application) {
        this.application = application;
    }

//    private void loadMostPopular(@NonNull MovieApiConfig movieApiConfig, @NonNull LoadMoviesCallback callback) {
//        RequestHandler.execute(
//                movieApiConfig.executePopular(Constants.API_KEY),
//                callback,
//                application.getApplicationContext()
//        );
//    }
//
//    private void loadTopRated(@NonNull MovieApiConfig movieApiConfig, @NonNull LoadMoviesCallback callback) {
//        RequestHandler.execute(
//                movieApiConfig.executeTopRated(Constants.API_KEY),
//                callback,
//                application.getApplicationContext()
//        );
//    }

    private void loadGithubInfo(@NonNull GitHubApiConfig movieApiConfig, @NonNull LoadsCommitsCallback callback) {
        RequestHandler.execute(
                movieApiConfig.executeGitHubInfo(),
                callback,
                application.getApplicationContext()
        );
    }

    @Override
    public void getCommitsList(@NonNull LoadsCommitsCallback callback) {
        GitHubApiConfig movieApiConfig = RequestHandler.getClient(Constants.BASE_URL).create(GitHubApiConfig.class);
        loadGithubInfo(movieApiConfig, callback);
        //movieApiConfig.executeGitHubInfo();
  //      switch (filter) {

//            case TOP_RATED:
//                loadTopRated(movieApiConfig, callback);
//                break;
//            case MOST_POPULAR:
//                loadMostPopular(movieApiConfig, callback);
//                break;
//            default:
     //   }
    }
}
