package com.rama.githubcommits;

public interface BaseView<T> {

}
