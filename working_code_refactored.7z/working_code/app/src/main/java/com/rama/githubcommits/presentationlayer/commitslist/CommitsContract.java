package com.rama.githubcommits.presentationlayer.commitslist;

import android.app.Activity;

import com.rama.githubcommits.BasePresenter;
import com.rama.githubcommits.models.RepoInfo;

import java.util.ArrayList;

public interface CommitsContract {
    interface View{
        void showCommits(ArrayList<RepoInfo> commits, boolean setAdapter);
        void showNoCommits();
        void showServerError(String error);
        void showNoInternetConnection();
    }

    interface Presenter extends BasePresenter<View> {
        void loadCommits();
        void setActivity(Activity activity);
    }
}
